
package com.demo.util;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Insert extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public Insert() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		Connection con=null;
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1522:xe", "NHL", "root");
			int id=Integer.parseInt(request.getParameter("id"));
			String e_name=request.getParameter("name");
			int age=Integer.parseInt(request.getParameter("age"));
			String gender=request.getParameter("gender");
			int contact=Integer.parseInt(request.getParameter("pnumber"));
			
			
			System.out.println("The values are "+ id+" "+e_name+" "+age+" "+gender+" "+contact);
			
			PreparedStatement pst=con.prepareStatement("insert into employees1 values(?,?,?,?,?)");
			System.out.println("After prepere statement"+ pst);
			pst.setInt(1, id);
			pst.setString(2, e_name);
			pst.setInt(3, age);
			pst.setString(4, gender);
			pst.setInt(5, contact);
			
			System.out.println("before execute Update");
			 pst.executeUpdate();
			 int i=0;
			System.out.println("value of i"+ i);
			if(i==0)
			{
				out.print(i+"sucessfully inserted");
			}
			else
			{
				out.print(i+" not sucessfully inserted");
			}
			
			
			con.close();
	 }catch(Exception e)
		{
			
		}
	}
	

}
